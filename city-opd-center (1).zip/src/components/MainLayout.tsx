/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { 
  Monitor, 
  Minus, 
  Maximize2, 
  X, 
  Search,
  Activity,
  MapPin,
  Calendar,
  User,
  ShieldCheck
} from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { ReactNode } from 'react';

interface MainLayoutProps {
  children: ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const location = useLocation();

  const navItems = [
    { label: "Home", icon: Activity, path: "/" },
    { label: "Book OPD", icon: Calendar, path: "/book" },
    { label: "Specialists", icon: Search, path: "/specialists" },
    { label: "Portal", icon: User, path: "/portal" },
  ];

  return (
    <div className="relative h-screen w-screen overflow-hidden font-sans select-none">
      {/* Background Gradients & Effects */}
      <div className="absolute inset-0 z-0">
        <motion.div 
          animate={{ backgroundPositionY: ['0px', '32px'] }}
          transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
          className="absolute inset-0 opacity-20" 
          style={{ backgroundImage: 'radial-gradient(white 0.5px, transparent 0.5px)', backgroundSize: '32px 32px' }} 
        />
        
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-teal-400/20 blur-[120px] rounded-full" />
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-emerald-500/10 blur-[150px] rounded-full" />
        
        <div className="absolute inset-0 opacity-[0.1] mix-blend-overlay pointer-events-none" 
             style={{ backgroundImage: 'url("https://grainy-gradients.vercel.app/noise.svg")' }} />
      </div>

      {/* Browser Bar Simulation */}
      <motion.div 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="absolute top-0 left-0 w-full h-8 bg-black/40 flex items-center px-4 gap-2 border-b border-white/5 z-50"
      >
        <div className="flex gap-1.5">
          <div className="w-3 h-3 rounded-full bg-red-500/50" />
          <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
          <div className="w-3 h-3 rounded-full bg-green-500/50" />
        </div>
        <div className="ml-4 bg-white/5 rounded px-3 py-1 text-[10px] text-white/40 font-mono w-64 tracking-tight flex items-center gap-2">
          <ShieldCheck size={10} className="text-teal-400/50" />
          cityopd.pioneerhealthcare.com{location.pathname}
        </div>
      </motion.div>

      {/* Top Branding */}
      <motion.div 
        initial={{ x: -10, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="absolute top-12 left-6 md:left-10 z-50 flex items-center gap-3 cursor-pointer"
      >
        <Link to="/" className="flex items-center gap-2 md:gap-3 group">
          <div className="w-8 h-8 md:w-10 md:h-10 border-2 border-white flex items-center justify-center rotate-45 group-hover:border-teal-400 transition-colors">
            <div className="w-4 h-1 md:w-6 md:h-1 border-t-2 border-white -rotate-45 group-hover:border-teal-400 transition-colors" />
            <div className="w-1 h-4 md:w-1 md:h-6 border-l-2 border-white -rotate-45 group-hover:border-teal-400 transition-colors" />
          </div>
          <div className="flex flex-col">
            <span className="text-white font-bold tracking-widest text-base md:text-lg leading-none uppercase">CITY OPD</span>
            <span className="text-teal-400 text-[8px] md:text-[10px] uppercase font-semibold tracking-[0.2em]">Pioneer Healthcare</span>
          </div>
        </Link>
      </motion.div>

      {/* Main View Container */}
      <div className="relative z-10 w-full h-full pt-12 pb-32 overflow-y-auto overflow-x-hidden custom-scrollbar">
        {children}
      </div>

      {/* Navigation Menu */}
      <motion.nav 
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 z-50"
      >
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 px-4 md:px-8 py-3 rounded-full flex gap-4 md:gap-10">
          {navItems.map((item, idx) => (
            <Link 
              key={idx}
              to={item.path}
              className={`text-[10px] md:text-xs uppercase tracking-widest font-bold transition-all px-2 py-1 rounded-full ${
                location.pathname === item.path 
                ? 'text-white bg-white/10' 
                : 'text-white/40 hover:text-white'
              }`}
            >
              <span className="hidden sm:inline">{item.label}</span>
              <item.icon size={14} className="sm:hidden" />
            </Link>
          ))}
        </div>
      </motion.nav>

      {/* Foreground Overlay (Desk Mockup) */}
      {location.pathname === '/' && (
        <div className="absolute bottom-0 inset-x-0 h-64 pointer-events-none z-40 overflow-hidden">
          <div className="absolute -bottom-8 left-1/2 -translate-x-[450px] w-80 h-32 bg-[#1a1a1a] rounded-t-xl border border-white/10 blur-[3px] opacity-60" />
          <div className="absolute bottom-[-20px] left-1/2 -translate-x-[50px] w-64 h-40 bg-[#e2be9f]/10 blur-[20px] rounded-full rotate-[-15deg]" />
          <div className="absolute bottom-6 left-1/2 -translate-x-1 w-20 h-32 bg-[#111] rounded-[40px] border border-white/5 blur-[4px] shadow-2xl" />
          <div className="absolute bottom-8 right-12 w-44 h-24 bg-[#0a0a0a] rounded-[24px] border border-white/10 blur-[2px] shadow-2xl opacity-90 overflow-hidden" />
        </div>
      )}

      {/* Side Accents */}
      <div className="absolute top-1/2 right-6 -translate-y-1/2 hidden lg:flex flex-col gap-4 z-50">
        <div className="w-[2px] h-12 bg-white/10" />
        <div className="w-[2px] h-4 bg-teal-400 shadow-[0_0_10px_rgba(45,212,191,0.5)]" />
        <div className="w-[2px] h-12 bg-white/10" />
      </div>

      {/* Scanning Line overlay */}
      <motion.div 
        animate={{ top: ['0%', '100%'] }}
        transition={{ duration: 12, repeat: Infinity, ease: 'linear' }}
        className="absolute left-0 w-full h-[1px] bg-teal-500/10 z-20 pointer-events-none"
      />
    </div>
  );
}
