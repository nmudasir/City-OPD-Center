/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import MainLayout from './components/MainLayout.tsx';
import Home from './views/Home.tsx';
import Booking from './views/Booking.tsx';
import Specialists from './views/Specialists.tsx';
import Portal from './views/Portal.tsx';

export default function App() {
  return (
    <Router>
      <MainLayout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/book" element={<Booking />} />
          <Route path="/specialists" element={<Specialists />} />
          <Route path="/portal" element={<Portal />} />
        </Routes>
      </MainLayout>
    </Router>
  );
}
