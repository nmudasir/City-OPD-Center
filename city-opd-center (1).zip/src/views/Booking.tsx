/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Clock, ChevronRight, CheckCircle2, User } from 'lucide-react';

export default function Booking() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    department: '',
    date: '',
    time: '',
    name: '',
    email: ''
  });

  const departments = ['Cardiology', 'Neurology', 'Orthopedics', 'General Medicine', 'Pediatrics'];
  const times = ['09:00 AM', '10:30 AM', '01:00 PM', '02:30 PM', '04:00 PM'];

  const handleNext = () => setStep(s => s + 1);

  return (
    <div className="h-full flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-2xl bg-black/40 backdrop-blur-3xl border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
        <div className="p-6 md:p-8 border-b border-white/5 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div>
            <h2 className="text-xl md:text-2xl font-bold tracking-tight text-white text-center sm:text-left">OPD Scheduler</h2>
            <p className="text-teal-400/60 text-[10px] uppercase tracking-widest font-bold text-center sm:text-left">Step {step} of 4</p>
          </div>
          <div className="flex gap-2">
            {[1, 2, 3, 4].map(s => (
              <div key={s} className={`w-8 h-1 rounded-full transition-all duration-500 ${s <= step ? 'bg-teal-400' : 'bg-white/10'}`} />
            ))}
          </div>
        </div>

        <div className="p-6 md:p-8 min-h-[400px] flex flex-col">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div 
                key="step1"
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -20, opacity: 0 }}
                className="space-y-4"
              >
                <label className="text-white/40 text-[10px] uppercase tracking-widest font-bold">Select Department</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {departments.map(dept => (
                    <button
                      key={dept}
                      onClick={() => { setFormData({...formData, department: dept}); handleNext(); }}
                      className={`p-4 rounded-xl border text-left transition-all ${
                        formData.department === dept 
                        ? 'bg-teal-500/20 border-teal-500/50 text-white' 
                        : 'bg-white/5 border-white/5 text-white/40 hover:bg-white/10'
                      }`}
                    >
                      <span className="text-sm font-semibold">{dept}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div 
                key="step2"
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -20, opacity: 0 }}
                className="space-y-6"
              >
                <div className="space-y-4">
                  <label className="text-white/40 text-[10px] uppercase tracking-widest font-bold">Select Date</label>
                  <input 
                    type="date" 
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white outline-none focus:border-teal-500/50 transition-colors"
                    onChange={(e) => setFormData({...formData, date: e.target.value})}
                  />
                </div>
                <div className="space-y-4">
                  <label className="text-white/40 text-[10px] uppercase tracking-widest font-bold">Available Times</label>
                  <div className="flex flex-wrap gap-2">
                    {times.map(t => (
                      <button
                        key={t}
                        onClick={() => setFormData({...formData, time: t})}
                        className={`px-4 py-2 rounded-full border text-xs font-bold transition-all ${
                          formData.time === t 
                          ? 'bg-teal-500 text-white border-teal-500' 
                          : 'bg-white/5 border-white/10 text-white/40 hover:bg-white/10'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
                <button 
                  disabled={!formData.date || !formData.time}
                  onClick={handleNext}
                  className="w-full bg-white text-black font-bold py-4 rounded-xl disabled:opacity-30 transition-opacity flex items-center justify-center gap-2"
                >
                  Confirm Slot <ChevronRight size={16} />
                </button>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div 
                key="step3"
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -20, opacity: 0 }}
                className="space-y-6"
              >
                <div className="space-y-4">
                  <label className="text-white/40 text-[10px] uppercase tracking-widest font-bold">Patient Details</label>
                  <div className="space-y-3">
                    <div className="relative">
                      <User size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" />
                      <input 
                        placeholder="Full Name"
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-4 pl-12 text-white outline-none focus:border-teal-500/50 transition-colors"
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                      />
                    </div>
                    <input 
                      placeholder="Email Address"
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white outline-none focus:border-teal-500/50 transition-colors"
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                    />
                  </div>
                </div>
                <button 
                  disabled={!formData.name || !formData.email}
                  onClick={handleNext}
                  className="w-full bg-teal-500 text-white font-bold py-4 rounded-xl shadow-[0_0_20px_rgba(45,212,191,0.3)] hover:brightness-110 transition-all"
                >
                  Book Appointment
                </button>
              </motion.div>
            )}

            {step === 4 && (
              <motion.div 
                key="step4"
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="flex-1 flex flex-col items-center justify-center text-center space-y-6"
              >
                <div className="w-20 h-20 bg-teal-500/20 rounded-full flex items-center justify-center border border-teal-500/50">
                  <CheckCircle2 size={40} className="text-teal-400" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold text-white">Booking Confirmed</h3>
                  <p className="text-white/40 text-sm max-w-xs">Your appointment for {formData.department} is scheduled for {formData.date} at {formData.time}.</p>
                </div>
                <div className="p-4 bg-white/5 border border-white/10 rounded-2xl w-full text-left space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-white/40 font-bold uppercase tracking-widest">ID Reference</span>
                    <span className="text-teal-400 font-mono">CPD-{Math.random().toString(36).substr(2, 6).toUpperCase()}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-white/40 font-bold uppercase tracking-widest">Patient</span>
                    <span className="text-white">{formData.name}</span>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
