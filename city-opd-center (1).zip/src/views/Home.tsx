/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center h-full px-6 text-center">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1.2, ease: "easeOut" }}
        className="relative w-48 h-48 mb-12 flex items-center justify-center"
      >
        <div className="absolute w-full h-full border-4 border-white/20 rounded-full animate-pulse" />
        <div className="absolute w-32 h-32 border-2 border-teal-300/40 rounded-full animate-reverse-spin" />
        
        <div className="relative z-20">
          <div className="w-16 h-4 bg-white rounded-full shadow-[0_0_20px_rgba(255,255,255,0.4)]" />
          <div className="w-4 h-16 bg-white rounded-full absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 shadow-[0_0_20px_rgba(255,255,255,0.4)]" />
        </div>

        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute w-full h-1 bg-gradient-to-r from-transparent via-teal-300/30 to-transparent rotate-[30deg]" 
          />
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute w-full h-1 bg-gradient-to-r from-transparent via-teal-300/30 to-transparent -rotate-[30deg]" 
          />
        </div>
      </motion.div>

      <div className="max-w-4xl">
        <motion.h1 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="text-white text-4xl sm:text-6xl md:text-8xl font-black tracking-tighter mb-4 leading-[0.9]"
        >
          HEALTHCARE.<br/><span className="text-teal-300 glow-text">REVOLUTIONIZED.</span>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-white/60 text-base md:text-xl tracking-wide font-light max-w-sm md:max-w-lg mx-auto"
        >
          Leading OPD services and technology for your well-being.
        </motion.p>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-10"
        >
          <button 
            onClick={() => navigate('/book')}
            className="glass-pill px-10 py-3 text-xs uppercase font-bold tracking-[0.2em] hover:scale-105 active:scale-95 transition-all cursor-pointer"
          >
            Initialize Portal
          </button>
        </motion.div>
      </div>
    </div>
  );
}
