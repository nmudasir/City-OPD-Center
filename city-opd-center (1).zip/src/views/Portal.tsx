/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { 
  FileText, 
  Clock, 
  Activity, 
  TrendingUp, 
  Download, 
  AlertCircle,
  Stethoscope,
  Heart,
  User
} from 'lucide-react';

export default function Portal() {
  const records = [
    { title: 'Blood Analysis Report', date: '21 Oct 2025', type: 'Laboratory', status: 'Finalized' },
    { title: 'Cardiac Consultation', date: '15 Oct 2025', type: 'Cardiology', status: 'Archived' },
    { title: 'Neuro Imaging (MRI)', date: '08 Oct 2025', type: 'Neurology', status: 'Finalized' }
  ];

  return (
    <div className="h-full flex flex-col p-4 md:p-6 max-w-6xl mx-auto space-y-6 md:space-y-8 pb-10">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div className="space-y-1 w-full text-center lg:text-left">
          <h2 className="text-3xl md:text-4xl font-black text-white tracking-tighter">Patient Portal</h2>
          <div className="flex items-center justify-center lg:justify-start gap-2">
            <div className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
            <p className="text-teal-400/60 text-[10px] uppercase font-bold tracking-[0.2em]">Bio-Sync: Active Authentication</p>
          </div>
        </div>
        <div className="flex items-center gap-4 bg-white/5 p-3 rounded-2xl border border-white/5 w-full lg:w-auto">
          <div className="w-10 h-10 rounded-full bg-teal-500/20 flex items-center justify-center border border-teal-500/50 shrink-0">
            <User className="text-teal-400" size={20} />
          </div>
          <div className="overflow-hidden">
            <p className="text-xs font-bold text-white uppercase tracking-wider truncate">John Q. Patient</p>
            <p className="text-[10px] text-white/20 font-mono">UID: AIS-882-990</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        <motion.div 
          initial={{ y: 20, opacity: 0 }} 
          animate={{ y: 0, opacity: 1 }}
          className="bg-teal-500/10 border border-teal-500/20 rounded-3xl p-6 space-y-4"
        >
          <div className="flex justify-between">
            <Heart className="text-teal-400" size={24} />
            <TrendingUp size={16} className="text-teal-400" />
          </div>
          <div className="space-y-1">
            <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest">Average BPM</p>
            <p className="text-4xl font-black text-white">72<span className="text-sm font-light text-white/50 ml-1 italic">/min</span></p>
          </div>
          <div className="h-2 w-full bg-teal-500/20 rounded-full overflow-hidden">
            <motion.div initial={{ width: 0 }} animate={{ width: '70%' }} className="h-full bg-teal-400 shadow-[0_0_10px_rgba(45,212,191,0.5)]" />
          </div>
        </motion.div>

        <motion.div 
          initial={{ y: 20, opacity: 0 }} 
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-white/5 border border-white/10 rounded-3xl p-6 space-y-4"
        >
          <div className="flex justify-between">
            <Activity className="text-white/40" size={24} />
            <Stethoscope size={16} className="text-white/20" />
          </div>
          <div className="space-y-1">
            <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest">BP Systolic</p>
            <p className="text-4xl font-black text-white">120<span className="text-sm font-light text-white/50 ml-1 italic">mmHg</span></p>
          </div>
        </motion.div>

        <motion.div 
          initial={{ y: 20, opacity: 0 }} 
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-white/5 border border-white/10 rounded-3xl p-6 space-y-4"
        >
          <div className="flex justify-between">
            <AlertCircle className="text-orange-400/50" size={24} />
          </div>
          <div className="space-y-1">
            <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest">Next Screening</p>
            <p className="text-2xl font-black text-white">14 Nov 2025</p>
            <p className="text-[10px] text-orange-400/60 uppercase font-black tracking-widest">Urgent Advisory</p>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-white uppercase tracking-[0.2em] flex items-center gap-2">
              <FileText size={16} className="text-teal-400" />
              Digital Records
            </h3>
            <button className="text-[10px] text-teal-400 font-bold uppercase tracking-widest hover:underline transition-all">View All Vaults</button>
          </div>
          <div className="space-y-3">
            {records.map((record, i) => (
              <motion.div 
                key={i}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.3 + (i * 0.1) }}
                className="bg-black/30 border border-white/5 rounded-2xl p-4 flex items-center justify-between hover:border-white/20 transition-all group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center text-white/40 group-hover:text-teal-400 transition-colors">
                    <FileText size={20} />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">{record.title}</h4>
                    <div className="flex items-center gap-3 mt-0.5">
                      <span className="text-[10px] text-white/20 font-mono tracking-tighter uppercase">{record.type}</span>
                      <span className="text-[10px] text-white/20">•</span>
                      <span className="text-[10px] text-white/20 font-mono tracking-tighter uppercase">{record.date}</span>
                    </div>
                  </div>
                </div>
                <button className="p-2 rounded-lg hover:bg-teal-500/20 text-white/20 hover:text-teal-400 transition-all">
                  <Download size={18} />
                </button>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-black text-white uppercase tracking-[0.2em] flex items-center gap-2">
            <Clock size={16} className="text-teal-400" />
            Bio-Timeline
          </h3>
          <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-[1px] before:bg-white/10">
            {[1, 2].map((_, i) => (
              <div key={i} className="relative group">
                <div className="absolute -left-[1.35rem] top-1.5 w-3 h-3 rounded-full bg-black border-2 border-white/20 group-hover:border-teal-400 transition-colors" />
                <div className="bg-white/5 border border-white/5 rounded-2xl p-4 group-hover:bg-white/10 transition-all">
                  <p className="text-[9px] text-white/20 font-bold uppercase tracking-widest">Oct 14, 2025 • 09:42 AM</p>
                  <p className="text-xs text-white/80 mt-1 font-medium italic">"System vitals synchronized successfully. All baseline parameters show optimal performance under stress conditions."</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
