/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion } from 'motion/react';
import { Search, MapPin, Star, GraduationCap, ChevronRight } from 'lucide-react';

const SPECIALISTS = [
  { id: 1, name: 'Dr. Sarah Mitchell', dept: 'Cardiology', exp: '15 Years', rating: 4.9, img: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=200&h=200' },
  { id: 2, name: 'Dr. James Wilson', dept: 'Neurology', exp: '12 Years', rating: 4.8, img: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=200&h=200' },
  { id: 3, name: 'Dr. Elena Rodriguez', dept: 'Pediatrics', exp: '10 Years', rating: 5.0, img: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&q=80&w=200&h=200' },
  { id: 4, name: 'Dr. Michael Chen', dept: 'Orthopedics', exp: '18 Years', rating: 4.7, img: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=200&h=200' },
  { id: 5, name: 'Dr. Anita Desai', dept: 'Oncology', exp: '14 Years', rating: 4.9, img: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=200&h=200' },
  { id: 6, name: 'Dr. Robert Taylor', dept: 'General Medicine', exp: '20 Years', rating: 4.6, img: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?auto=format&fit=crop&q=80&w=200&h=200' },
];

export default function Specialists() {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All');

  const depts = ['All', 'Cardiology', 'Neurology', 'Pediatrics', 'Orthopedics', 'Oncology'];

  const filteredDocs = SPECIALISTS.filter(doc => 
    (filter === 'All' || doc.dept === filter) &&
    (doc.name.toLowerCase().includes(query.toLowerCase()) || doc.dept.toLowerCase().includes(query.toLowerCase()))
  );

  return (
    <div className="h-full flex flex-col p-4 md:p-6 max-w-6xl mx-auto space-y-6 md:space-y-8">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
        <div className="space-y-2 text-center lg:text-left">
          <h2 className="text-3xl md:text-4xl font-black text-white tracking-tighter">Medical Board</h2>
          <p className="text-white/40 text-xs md:text-sm">Certified specialists delivering world-class care.</p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" />
            <input 
              placeholder="Search specialists..."
              className="bg-white/5 border border-white/10 rounded-full px-12 py-3 text-white text-[10px] uppercase font-bold tracking-widest outline-none focus:border-teal-500/50 w-full md:w-64"
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <div className="flex gap-1 bg-white/5 p-1 rounded-full border border-white/5 overflow-x-auto no-scrollbar scroll-smooth">
            {depts.map(d => (
              <button
                key={d}
                onClick={() => setFilter(d)}
                className={`px-4 py-2 rounded-full text-[10px] uppercase font-bold tracking-widest transition-all whitespace-nowrap ${
                  filter === d ? 'bg-teal-500 text-white' : 'text-white/40 hover:text-white'
                }`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pr-2">
        {filteredDocs.map((doc, idx) => (
          <motion.div
            key={doc.id}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: idx * 0.1 }}
            className="group bg-black/30 backdrop-blur-md border border-white/10 rounded-3xl p-6 hover:border-teal-500/30 transition-all hover:bg-black/50"
          >
            <div className="flex items-start justify-between mb-6">
              <div className="w-20 h-20 rounded-2xl overflow-hidden grayscale group-hover:grayscale-0 transition-all duration-500 border border-white/10">
                <img src={doc.img} alt={doc.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div className="flex flex-col items-end gap-1">
                <div className="flex items-center gap-1 text-teal-400">
                  <Star size={12} fill="currentColor" />
                  <span className="text-xs font-black">{doc.rating}</span>
                </div>
                <div className="text-[10px] text-white/20 font-bold uppercase tracking-widest">Global Rank # {idx + 1}</div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-bold text-white group-hover:text-teal-400 transition-colors">{doc.name}</h3>
                <p className="text-white/40 text-xs font-medium uppercase tracking-widest">{doc.dept}</p>
              </div>
              
              <div className="flex items-center gap-6 py-4 border-y border-white/5">
                <div className="flex items-center gap-2">
                  <GraduationCap size={14} className="text-white/20" />
                  <span className="text-[10px] text-white/40 font-bold uppercase tracking-tighter">{doc.exp}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin size={14} className="text-white/20" />
                  <span className="text-[10px] text-white/40 font-bold uppercase tracking-tighter">Main Wing</span>
                </div>
              </div>

              <button className="w-full py-3 rounded-xl border border-white/5 text-[10px] uppercase font-bold tracking-[0.2em] text-white/60 group-hover:bg-teal-500 group-hover:text-white group-hover:border-teal-400 transition-all flex items-center justify-center gap-2">
                Consult Slot <ChevronRight size={12} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
